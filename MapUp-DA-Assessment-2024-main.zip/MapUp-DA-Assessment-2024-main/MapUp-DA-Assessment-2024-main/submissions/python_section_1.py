# Question 1: Reverse List by N Elements
def reverse_groups(arr, n):
   
    return [val for i in range(0, len(arr), n) for val in reversed(arr[i:i+n])]
 

arr = [1, 2, 3, 4, 5, 6, 7, 8]
n = 3
print(reverse_groups(arr, n))  
 
arr = [1, 2, 3, 4, 5]
n= 2
print(reverse_groups(arr, n))  
 
arr = [10, 20, 30, 40, 50, 60, 70]
n = 4
print(reverse_groups(arr, n))  

# Question 2: Lists & Dictionaries

def group_strings_by_length(strings):
    length_dict = {}
    for s in strings:
        length = len(s)
        if length not in length_dict:
            length_dict[length] = []
        length_dict[length].append(s)
    return dict(sorted(length_dict.items()))

strings = ['apple', 'bat', 'car','elephant', 'dog', 'bear']
result = group_strings_by_length(strings)
string1=["one","two","three","four"]
result2=group_strings_by_length(string1)
print(result)
print(result2)

# Q-3 Flatten a Nested Dictionary

my_map= {
    "road": {
        "name": "Highway 1",
        "length": 350,
        "sections": [
            {
                "id": 1,
                "condition": {
                    "pavement": "good",
                    "traffic": "moderate"
                }
            }
        ]
    }
}

def flatten_dict(pyobj, keystring=''):
    if type(pyobj) == dict:
        keystring = keystring + '_' if keystring else keystring
        for k in pyobj:
            yield from flatten_dict(pyobj[k], keystring + str(k))
    else:
        yield keystring, pyobj
 
print("Input : %s\nOutput : %s\n\n" %
     (my_map, { k:v for k,v in flatten_dict(my_map) }))


# Q-4 Generate Unique Permutations

def backtrack():
    global ans, curr, visited, nums
     
   
    if (len(curr) == len(nums)):
        print(*curr)

    for i in range(len(nums)):
 
        if (visited[i]):
            continue
        if (i > 0 and nums[i] == nums[i - 1] and visited[i - 1]==False):
            continue
        visited[i] = True
        curr.append(nums[i])
 
        backtrack()
        visited[i] = False
        del curr[-1]
 

def permuteDuplicates(nums):
    global ans, visited, curr
    nums = sorted(nums)
    backtrack()
    return ans
 

def getDistinctPermutations(nums):
    global ans, curr, visited
     

    ans = permuteDuplicates(nums)

if __name__== '_main_':
    visited = [False]*(5)
    ans,curr = [], []
    nums = [1, 2, 2]
getDistinctPermutations(nums)

#Question 5: Find All Dates in a Text
import re
def find_all_dates(text):
    pattern = r'\b(\d{2}-\d{2}-\d{4})\b|\b(\d{2}/\d{2}/\d{4})\b|\b(\d{4}\.\d{2}\.\d{2})\b'
    matches = re.findall(pattern, text)
    dates = [date for match in matches for date in match if date]   
    return dates

text = "I was born on 23-08-1994, my friend on 08/23/1994, and another one on 1994.08.23."
print(find_all_dates(text))


# Question 6: Decode Polyline, Convert to DataFrame with Distances

import polyline
import pandas as pd
import math


def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2) * 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) * 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    distance = R * c  
    return distance

def polyline_to_dataframe(polyline_str):
    coordinates = polyline.decode(polyline_str)
    df = pd.DataFrame(coordinates, columns=['latitude', 'longitude'])  
    distances = [0]    
    for i in range(1, len(df)):
        lat1, lon1 = df.loc[i - 1, 'latitude'], df.loc[i - 1, 'longitude']
        lat2, lon2 = df.loc[i, 'latitude'], df.loc[i, 'longitude']
        distance = haversine(lat1, lon1, lat2, lon2)
        distances.append(distance)

    df['distance'] = distances
    
    return df


polyline_str = '_p~iF~ps|U_ulLnnqC_mqNvxq`@'  
df = polyline_to_dataframe(polyline_str)
print(df)

#question-7

import numpy as np
def rotate_and_transform(matrix):
    n = len(matrix)
    rotated_matrix = np.rot90(matrix, k=-1)
    transformed_matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            row_sum = sum(rotated_matrix[i]) - rotated_matrix[i][j]
            col_sum = sum(rotated_matrix[k][j] for k in range(n)) - rotated_matrix[i][j]
            transformed_matrix[i][j] = row_sum + col_sum
    return transformed_matrix

matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]
result = rotate_and_transform(matrix)
for row in result:
    print(row)


# Question 8: Time Check

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
def check_timestamp_completeness(df):
 
    df['startTimestamp'] = pd.to_datetime(df['startDay'] + ' ' + df['startTime'])
    df['endTimestamp'] = pd.to_datetime(df['endDay'] + ' ' + df['endTime'])
    def is_complete(group):

        start_of_week = group['startTimestamp'].min().normalize()
        end_of_week = start_of_week + timedelta(days=7) - timedelta(seconds=1)
        full_time_range = pd.date_range(start=start_of_week, end=end_of_week, freq='S')
        covered_range = pd.concat([pd.date_range(row['startTimestamp'], row['endTimestamp'], freq='S')
                                   for _, row in group.iterrows()])
        
        return set(full_time_range).issubset(set(covered_range))

    completeness_check = df.groupby(['id', 'id_2']).apply(is_complete)
    return ~completeness_check
df = pd.read_csv('dataset-1.csv') 
result = check_timestamp_completeness(df)
print(result)