# Q-9 Distance Matrix Calculation

import pandas as pd
import numpy as np

file_path = './dataset-2.csv'
df = pd.read_csv(file_path)

df.head()

def calculate_distance_matrix(df):

    unique_ids = np.unique(df[['id_start', 'id_end']].values)
    distance_matrix = pd.DataFrame(np.inf, index=unique_ids, columns=unique_ids)
    np.fill_diagonal(distance_matrix.values, 0)
    
    for _, row in df.iterrows():
        start, end, dist = row['id_start'], row['id_end'], row['distance']
        distance_matrix.loc[start, end] = dist
        distance_matrix.loc[end, start] = dist
    
    return distance_matrix

distance_matrix = calculate_distance_matrix(df)
distance_matrix.head()

# Q-10 Unroll Distance Matrix

def unroll_distance_matrix(distance_matrix):

    unrolled_df = distance_matrix.stack().reset_index()
    
    unrolled_df.columns = ['id_start', 'id_end', 'distance']
    
    unrolled_df = unrolled_df[unrolled_df['id_start'] != unrolled_df['id_end']]
    
    return unrolled_df

unrolled_distance_df = unroll_distance_matrix(distance_matrix)
unrolled_distance_df.head()

# Q-11 Finding IDs within Percentage Threshold

def find_ids_within_ten_percentage_threshold(df, reference_value):
    
    reference_distances = df[df['id_start'] == reference_value]['distance']
    
    avg_distance = reference_distances.mean()
    
    lower_bound = avg_distance * 0.9
    upper_bound = avg_distance * 1.1
    
    ids_within_threshold = df[(df['distance'] >= lower_bound) & 
                              (df['distance'] <= upper_bound)]['id_start'].unique()
    
    return sorted(ids_within_threshold)

# Q-12 Calculate Toll Rate

def calculate_toll_rate(df):
    rate_coefficients = {
        'moto': 0.05,
        'car': 0.10,
        'rv': 0.15,
        'bus': 0.20,
        'truck': 0.25
    }
    
    for vehicle, rate in rate_coefficients.items():
        df[vehicle] = df['distance'] * rate
    
    return df

# Q-13 Calculate Time-Based Toll Rates

import pandas as pd
from datetime import time

def calculate_time_based_toll_rates(df):
    discount_factors = {
        'weekdays': {
            '00:00:00-10:00:00': 0.8,
            '10:00:00-18:00:00': 1.2,
            '18:00:00-23:59:59': 0.8
        },
        'weekends': 0.7
    }
    
    weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    weekends = ['Saturday', 'Sunday']
    
    expanded_rows = []
    
    for _, row in df.iterrows():
        for day in weekdays + weekends:
            if day in weekdays:
                for time_range, discount in discount_factors['weekdays'].items():
                    start_time_str, end_time_str = time_range.split('-')
                    start_time = time.fromisoformat(start_time_str)
                    end_time = time.fromisoformat(end_time_str)
                    
                    new_row = row.copy()
                    new_row['start_day'] = day
                    new_row['end_day'] = day
                    new_row['start_time'] = start_time
                    new_row['end_time'] = end_time
                    
                    for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                        new_row[vehicle] = row[vehicle] * discount
                    
                    expanded_rows.append(new_row)
            else:
                start_time = time(0, 0)
                end_time = time(23, 59, 59)
                
                new_row = row.copy()
                new_row['start_day'] = day
                new_row['end_day'] = day
                new_row['start_time'] = start_time
                new_row['end_time'] = end_time
                
                for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                    new_row[vehicle] = row[vehicle] * discount_factors['weekends']
                
                expanded_rows.append(new_row)
    
    expanded_df = pd.DataFrame(expanded_rows)
    
    return expanded_df